#include "list.h"

#include <assert.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>

struct list {
    LIST *prox;
    unsigned int max, size;
    int num;
};

LIST *list_create(unsigned int max) {
    LIST temp;
    LIST *L = &temp;
    temp.max = max;
    temp.size = 0;
    temp.prox = NULL;
    return L;
}

void list_destroy(LIST *list) {
    LIST *p;
    unsigned int i;
    do {
        for (i = 0, p = list; i < list->size - 1; i++, p = p->prox);
        free(p->prox);
        list->size--;
    } while (list->size > 0);
}

unsigned int list_max(LIST *list) { return list->max; }

unsigned int list_size(LIST *list) { return list->size; }

void list_print(LIST *list, unsigned int idx) {
    int value = list_value(list, idx);
    printf("%d\n", value);
}


void list_insert(LIST *list, int value, unsigned int k) {
    unsigned int i, j;
    LIST *p;
    if (k >= list->max || list->size == list->max || k < list->size)
        printf("ERRO!\n");
    else {
        // placing p in the last position to move the necessary values
        // one position ahead
        for (i = 0, p = list; i < list->size - 1; i++, p = p->prox);
        p->prox = (LIST *) malloc(sizeof(LIST));
        p->prox->num = p->num;

        j = list->size - 1;
        do {
            for (i = 0; i < j; i++, p = p->prox);
            p->prox->num = p->num;
            j--;

        } while (j >= k);

        p->num = value;

        list->size++;
    }
}

void list_delete(LIST *list, unsigned int k) {
    unsigned int i;
    LIST *p;

    //setting p in the k position
    for (i = 0, p = list; i < k; i++, p = p->prox);
}

int list_value(LIST *list, unsigned int idx) {
    unsigned int i;
    LIST *p = list;

    for (i = 0; i < idx; i++, p = p->prox);

    return p->num;
}

void list_change(LIST *list, int value, unsigned int idx) {
    unsigned int i;
    LIST *p = list;
    if (idx >= list->size)
        printf("ERRO!\n");
    else {
        for (i = 0; i < idx; i++, p = p->prox);
        p->num = value;
    }
}
